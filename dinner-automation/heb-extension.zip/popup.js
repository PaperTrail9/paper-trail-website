/**
 * HEB Auto-Cart Extension Popup
 * Handles UI interactions and communication with content script
 */

// State
let currentItems = [];
let isRunning = false;
let totalItems = 0;
let completedItems = 0;

// DOM Elements
const mealPlanInput = document.getElementById('mealPlanInput');
const loadBtn = document.getElementById('loadBtn');
const uploadBtn = document.getElementById('uploadBtn');
const fileInput = document.getElementById('fileInput');
const itemsSection = document.getElementById('itemsSection');
const itemCount = document.getElementById('itemCount');
const itemList = document.getElementById('itemList');
const actionSection = document.getElementById('actionSection');
const startBtn = document.getElementById('startBtn');
const resetBtn = document.getElementById('resetBtn');
const progressSection = document.getElementById('progressSection');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');
const statusSection = document.getElementById('statusSection');
const inputSection = document.getElementById('inputSection');

// Event Listeners
document.addEventListener('DOMContentLoaded', init);
loadBtn.addEventListener('click', loadFromText);
uploadBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', loadFromFile);
startBtn.addEventListener('click', startAutomation);
resetBtn.addEventListener('click', reset);

/**
 * Initialize popup
 */
function init() {
  console.log('Popup initialized');
  
  // Load saved state
  chrome.storage.local.get(['items', 'isRunning', 'progress', 'total'], (result) => {
    console.log('Loaded state:', result);
    
    if (result.items && result.items.length > 0) {
      currentItems = result.items;
      totalItems = result.items.length;
      displayItems();
      
      if (result.isRunning) {
        isRunning = true;
        showProgress(result.progress || 0, totalItems);
        startBtn.disabled = true;
        startBtn.textContent = 'Adding Items...';
        
        // Reconnect to running automation
        showStatus('Reconnected to running automation...', 'info');
      }
    }
  });
  
  // Set up message listener for progress updates
  chrome.runtime.onMessage.addListener(handleMessage);
}

/**
 * Handle messages from content script
 */
function handleMessage(message, sender, sendResponse) {
  console.log('Popup received message:', message);
  
  switch (message.action) {
    case 'automationStarted':
      isRunning = true;
      totalItems = message.total || currentItems.length;
      showStatus('🚀 Starting automation...', 'info');
      break;
      
    case 'progress':
      completedItems = message.completed;
      updateItemStatus(message.currentItem, message.itemStatus);
      showProgress(message.completed, message.total);
      
      if (message.message) {
        showStatus(message.message, 'info');
      }
      
      // Save progress
      chrome.storage.local.set({ 
        progress: message.completed,
        total: message.total 
      });
      break;
      
    case 'automationComplete':
      isRunning = false;
      startBtn.disabled = false;
      startBtn.textContent = 'Start Adding Items';
      
      const successMsg = `✅ Complete! Added ${message.added}/${message.total} items`;
      showStatus(successMsg, 'success');
      
      if (message.failedItems && message.failedItems.length > 0) {
        const failedMsg = `❌ Failed: ${message.failedItems.map(f => f.item).join(', ')}`;
        appendStatus(failedMsg, 'warning');
      }
      
      chrome.storage.local.set({ isRunning: false });
      break;
      
    case 'automationError':
      isRunning = false;
      startBtn.disabled = false;
      startBtn.textContent = 'Start Adding Items';
      showStatus('❌ Error: ' + message.error, 'error');
      chrome.storage.local.set({ isRunning: false });
      break;
  }
}

/**
 * Load items from textarea input
 */
function loadFromText() {
  try {
    const json = mealPlanInput.value.trim();
    if (!json) {
      showStatus('Please paste a meal plan JSON', 'error');
      return;
    }
    
    const mealPlan = JSON.parse(json);
    extractItems(mealPlan);
    showStatus(`✅ Loaded ${currentItems.length} items!`, 'success');
  } catch (error) {
    showStatus('❌ Invalid JSON: ' + error.message, 'error');
    console.error('JSON parse error:', error);
  }
}

/**
 * Load items from file upload
 */
function loadFromFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const mealPlan = JSON.parse(e.target.result);
      mealPlanInput.value = e.target.result;
      extractItems(mealPlan);
      showStatus(`✅ Loaded ${currentItems.length} items from file!`, 'success');
    } catch (error) {
      showStatus('❌ Invalid JSON file: ' + error.message, 'error');
      console.error('File parse error:', error);
    }
  };
  reader.onerror = () => {
    showStatus('❌ Error reading file', 'error');
  };
  reader.readAsText(file);
}

/**
 * Extract items from meal plan object
 */
function extractItems(mealPlan) {
  currentItems = [];
  const seen = new Set();
  
  if (!mealPlan.meals || !Array.isArray(mealPlan.meals)) {
    // Try alternative formats
    if (mealPlan.ingredients && Array.isArray(mealPlan.ingredients)) {
      // Direct ingredients array
      for (const ingredient of mealPlan.ingredients) {
        addItemFromIngredient(ingredient, seen);
      }
    } else {
      showStatus('Invalid meal plan format: missing meals array', 'error');
      return;
    }
  } else {
    // Standard format with meals
    for (const meal of mealPlan.meals) {
      if (!meal.ingredients) continue;
      
      for (const ingredient of meal.ingredients) {
        addItemFromIngredient(ingredient, seen);
      }
    }
  }
  
  totalItems = currentItems.length;
  
  // Save to storage
  chrome.storage.local.set({ 
    items: currentItems,
    total: totalItems,
    progress: 0,
    isRunning: false
  });
  
  displayItems();
  console.log('Extracted items:', currentItems);
}

/**
 * Add item from ingredient object
 */
function addItemFromIngredient(ingredient, seen) {
  const searchTerm = ingredient.hebSearch || ingredient.name || ingredient;
  const name = ingredient.name || searchTerm;
  const amount = ingredient.amount || '1';
  
  // Skip duplicates
  const key = searchTerm.toLowerCase();
  if (seen.has(key)) return;
  seen.add(key);
  
  currentItems.push({
    name: name,
    searchTerm: searchTerm,
    amount: amount,
    status: 'pending'
  });
}

/**
 * Display items in the list
 */
function displayItems() {
  itemCount.textContent = currentItems.length;
  itemList.innerHTML = '';
  
  for (const item of currentItems) {
    const div = document.createElement('div');
    div.className = 'item';
    div.id = `item-${item.name.replace(/\s+/g, '-').toLowerCase()}`;
    div.innerHTML = `
      <span>${item.name} (${item.amount})</span>
      <span class="item-status ${item.status}">${item.status}</span>
    `;
    itemList.appendChild(div);
  }
  
  itemsSection.style.display = 'block';
  actionSection.style.display = 'block';
}

/**
 * Update item status in the list
 */
function updateItemStatus(itemName, status) {
  // Find item by name
  const item = currentItems.find(i => i.name === itemName || i.searchTerm === itemName);
  if (item) {
    item.status = status;
    
    // Update the DOM
    const itemDiv = document.getElementById(`item-${item.name.replace(/\s+/g, '-').toLowerCase()}`);
    if (itemDiv) {
      const statusSpan = itemDiv.querySelector('.item-status');
      if (statusSpan) {
        statusSpan.className = `item-status ${status}`;
        statusSpan.textContent = status;
      }
    }
  }
}

/**
 * Start the automation process
 */
async function startAutomation() {
  if (currentItems.length === 0) {
    showStatus('No items to add', 'error');
    return;
  }
  
  if (isRunning) {
    showStatus('Automation already running', 'warning');
    return;
  }
  
  try {
    // Get current tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];
    
    if (!currentTab) {
      showStatus('No active tab found', 'error');
      return;
    }
    
    // Check if we're on HEB.com
    if (!currentTab.url || !currentTab.url.includes('heb.com')) {
      showStatus('Opening HEB.com in new tab...', 'info');
      chrome.tabs.create({ url: 'https://www.heb.com' });
      return;
    }
    
    isRunning = true;
    startBtn.disabled = true;
    startBtn.textContent = 'Adding Items...';
    
    // Reset statuses
    currentItems.forEach(item => item.status = 'pending');
    displayItems();
    showProgress(0, currentItems.length);
    
    // Save state
    chrome.storage.local.set({ 
      isRunning: true, 
      progress: 0,
      items: currentItems 
    });
    
    // Send message to content script
    chrome.tabs.sendMessage(currentTab.id, {
      action: 'startAutomation',
      items: currentItems
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Content script error:', chrome.runtime.lastError);
        showStatus('❌ Error: Content script not loaded. Please refresh HEB.com page.', 'error');
        reset();
      } else {
        console.log('Content script response:', response);
      }
    });
    
  } catch (error) {
    console.error('Start automation error:', error);
    showStatus('❌ Error: ' + error.message, 'error');
    reset();
  }
}

/**
 * Show progress UI
 */
function showProgress(completed, total) {
  progressSection.classList.add('active');
  const percent = total > 0 ? (completed / total) * 100 : 0;
  progressFill.style.width = `${percent}%`;
  progressText.textContent = `${completed} / ${total} items added (${Math.round(percent)}%)`;
}

/**
 * Reset the extension state
 */
function reset() {
  currentItems = [];
  isRunning = false;
  totalItems = 0;
  completedItems = 0;
  
  chrome.storage.local.remove(['items', 'isRunning', 'progress', 'total']);
  
  mealPlanInput.value = '';
  itemsSection.style.display = 'none';
  actionSection.style.display = 'none';
  progressSection.classList.remove('active');
  startBtn.disabled = false;
  startBtn.textContent = 'Start Adding Items';
  statusSection.innerHTML = '';
  
  showStatus('Reset complete', 'info');
}

/**
 * Show status message
 */
function showStatus(message, type) {
  statusSection.innerHTML = `<div class="status ${type}">${message}</div>`;
}

/**
 * Append status message
 */
function appendStatus(message, type) {
  const existing = statusSection.innerHTML;
  statusSection.innerHTML = existing + `<div class="status ${type}">${message}</div>`;
}
