/**
 * HEB Auto-Cart Background Service Worker
 * Handles extension lifecycle and cross-tab communication
 */

console.log('🛒 HEB Auto-Cart: Background script loaded');

// Extension installation
chrome.runtime.onInstalled.addListener((details) => {
  console.log('HEB Auto-Cart extension installed/updated');
  
  if (details.reason === 'install') {
    console.log('First install - setting defaults');
    // Set default settings
    chrome.storage.local.set({
      delay: 3000,  // Default delay between items (ms)
      autoCloseModals: true,
      showNotifications: true
    });
  }
});

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message, 'from:', sender);
  
  switch (message.action) {
    case 'automationStarted':
      console.log('Automation started on tab:', sender.tab?.id);
      // Broadcast to popup if open
      chrome.runtime.sendMessage({
        action: 'automationStarted',
        total: message.total
      }).catch(() => {}); // Ignore error if popup is closed
      break;
      
    case 'progress':
      // Forward progress to popup
      chrome.runtime.sendMessage({
        action: 'progress',
        completed: message.completed,
        total: message.total,
        currentItem: message.currentItem,
        itemStatus: message.itemStatus,
        message: message.message
      }).catch(() => {});
      break;
      
    case 'automationComplete':
      console.log('Automation complete on tab:', sender.tab?.id);
      
      // Show notification if enabled
      chrome.storage.local.get(['showNotifications'], (result) => {
        if (result.showNotifications !== false) {
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'HEB Auto-Cart',
            message: `✅ Added ${message.added}/${message.total} items to your cart!`
          });
        }
      });
      
      // Forward to popup
      chrome.runtime.sendMessage({
        action: 'automationComplete',
        added: message.added,
        failed: message.failed,
        total: message.total,
        failedItems: message.failedItems
      }).catch(() => {});
      break;
      
    case 'automationError':
      console.error('Automation error:', message.error);
      
      // Show error notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'HEB Auto-Cart - Error',
        message: `❌ ${message.error}`
      });
      
      // Forward to popup
      chrome.runtime.sendMessage({
        action: 'automationError',
        error: message.error
      }).catch(() => {});
      break;
  }
});

// Handle tab updates (cleanup if user navigates away)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && !tab.url.includes('heb.com')) {
    // User navigated away from HEB
    chrome.storage.local.get(['isRunning'], (result) => {
      if (result.isRunning) {
        console.log('User navigated away from HEB, stopping automation');
        chrome.storage.local.set({ isRunning: false });
      }
    });
  }
});

// Handle tab removal
chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get(['isRunning'], (result) => {
    if (result.isRunning) {
      console.log('Tab closed, stopping automation');
      chrome.storage.local.set({ isRunning: false });
    }
  });
});

// Keep service worker alive during automation
chrome.runtime.onConnect.addListener((port) => {
  console.log('Port connected:', port.name);
  
  port.onDisconnect.addListener(() => {
    console.log('Port disconnected:', port.name);
  });
});

// Alarm to check automation status periodically
chrome.alarms?.create?.('keepAlive', { periodInMinutes: 1 });
chrome.alarms?.onAlarm?.addListener((alarm) => {
  if (alarm.name === 'keepAlive') {
    console.log('Keep alive check');
  }
});

console.log('🛒 HEB Auto-Cart: Background script ready');
