# HEB Auto-Cart - Quick Install Guide

## 🚀 Install in 30 Seconds

### 1. Open Chrome Extensions
```
chrome://extensions/
```

### 2. Enable Developer Mode
Toggle the switch in the top-right corner

### 3. Load Extension
1. Click **"Load unpacked"**
2. Navigate to: `C:\Users\Admin\.openclaw\workspace\dinner-automation\heb-extension`
3. Click **"Select Folder"**

### 4. Done! 🎉
The HEB Auto-Cart icon should appear in your toolbar.

---

## 📖 Usage

### Quick Start
1. Go to **heb.com** and log in
2. Click the **🛒 HEB Auto-Cart** icon
3. **Upload** or **paste** your `weekly-plan.json`
4. Click **"Start Adding Items"**
5. Wait 2-3 minutes while it runs
6. Check your cart! ✅

### Weekly Plan Location
```
C:\Users\Admin\.openclaw\workspace\dinner-automation\data\weekly-plan.json
```

---

## ⚠️ Important Tips

| Do | Don't |
|----|-------|
| ✅ Keep the popup open during automation | ❌ Close the popup while running |
| ✅ Stay on heb.com | ❌ Navigate to other sites |
| ✅ Log into HEB first | ❌ Run on mobile |
| ✅ Wait for completion | ❌ Refresh the page |

---

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Content script not loaded" | Refresh HEB.com page |
| Items not adding | Check that you're logged in |
| Extension not appearing | Click 🧩 puzzle icon → Pin it |
| Need to update code | Click ↻ refresh on extension card |

---

## 📊 Current Plan: Feb 7, 2026

**32 ingredients** across **5 meals**

- Fish Tacos with Mango Salsa
- Pan-Seared Cod with Lemon Butter  
- Lemon Herb Grilled Chicken
- Korean Beef Bulgogi Bowl
- Mediterranean Chicken Bowl

**Estimated Runtime:** 2-3 minutes

---

**Ready to automate your grocery shopping?** Open heb.com and click the extension icon!
