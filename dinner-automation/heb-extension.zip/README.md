# HEB Auto-Cart Chrome Extension

🛒 **Automatically add your weekly meal plan ingredients to your HEB cart!**

## Overview

This Chrome extension reads your dinner plan JSON and automatically searches for each ingredient on HEB.com and adds it to your cart.

## Features

- ✅ Read weekly meal plan JSON (5 meals, 32+ ingredients)
- 🔍 Search HEB.com for each ingredient automatically
- 🛒 Add items to cart with one click
- 📊 Real-time progress tracking
- ⚠️ Error handling and recovery
- 🔄 Works with the current HEB.com website

## Installation

### Step 1: Open Chrome Extensions Page
1. Open Google Chrome
2. Type `chrome://extensions/` in the address bar and press Enter
3. OR click the Chrome menu (⋮) → More Tools → Extensions

### Step 2: Enable Developer Mode
1. Toggle the "Developer mode" switch in the top-right corner
2. You should see new buttons appear: "Load unpacked", "Pack extension", etc.

### Step 3: Load the Extension
1. Click the **"Load unpacked"** button
2. Navigate to: `C:\Users\Admin\.openclaw\workspace\dinner-automation\heb-extension`
3. Select the **heb-extension** folder (the one containing manifest.json)
4. Click "Select Folder"

### Step 4: Verify Installation
1. You should see "HEB Auto-Cart" appear in your extensions list
2. The extension icon (red square) should appear in your Chrome toolbar
3. You may need to click the puzzle icon (🧩) and pin the extension to keep it visible

## Usage

### Step 1: Navigate to HEB.com
1. Go to <https://www.heb.com>
2. Make sure you're logged into your HEB account (optional but recommended)
3. Set your store location if prompted

### Step 2: Open the Extension
1. Click the HEB Auto-Cart icon in your Chrome toolbar
2. The popup will open

### Step 3: Load Your Meal Plan
**Option A: Paste JSON**
1. Open `C:\Users\Admin\.openclaw\workspace\dinner-automation\data\weekly-plan.json`
2. Copy all the content
3. Paste it into the extension's text area
4. Click "Load Items"

**Option B: Upload File**
1. Click "Or Upload JSON File"
2. Select `weekly-plan.json` from the file picker
3. The items will load automatically

### Step 4: Start Automation
1. Review the items that will be added
2. Click **"Start Adding Items"**
3. The extension will:
   - Search for each ingredient on HEB.com
   - Click "Add to Cart" on the first result
   - Show progress in real-time
   - Wait 2-4 seconds between items to avoid rate limiting

### Step 5: Monitor Progress
- Watch the progress bar fill up
- See which items are being added
- Check for any errors

### Step 6: Complete
- When finished, you'll see a success message
- Check your HEB cart to verify items were added
- Any failed items will be listed (you can add them manually)

## Troubleshooting

### Extension Not Loading
- Make sure Developer Mode is enabled
- Make sure you selected the correct folder (the one with manifest.json)
- Check the error message in the extensions page

### "Content script not loaded" Error
- Make sure you're on HEB.com before clicking "Start"
- Refresh the HEB.com page and try again

### Items Not Being Added
- Make sure you're logged into HEB.com
- Check that you have a store location set
- Some items may be out of stock - these will be marked as failed
- Try searching for the item manually to verify it exists

### Page Navigation Issues
- Keep the popup open during automation
- Don't navigate away from HEB.com while running
- Don't close the tab while automation is active

### Slow Performance
- The extension waits 2-4 seconds between items intentionally
- This prevents HEB.com from blocking the automation
- A full meal plan (32 items) will take approximately 2-3 minutes

## Current Weekly Plan

**Week of:** February 7, 2026

**Meals:**
1. **Sunday:** Fish Tacos with Mango Salsa (7 items)
2. **Monday:** Pan-Seared Cod with Lemon Butter (6 items)
3. **Tuesday:** Lemon Herb Grilled Chicken (6 items)
4. **Wednesday:** Korean Beef Bulgogi Bowl (6 items)
5. **Thursday:** Mediterranean Chicken Bowl (7 items)

**Total Items:** 32 ingredients

**Estimated Time:** 2-3 minutes

## File Structure

```
heb-extension/
├── manifest.json      # Extension manifest
├── popup.html         # Popup UI
├── popup.js           # Popup logic
├── content.js         # Content script (runs on HEB.com)
├── background.js      # Background service worker
├── icons/             # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── README.md          # This file
└── INSTALL.md         # Installation guide
```

## Data Files

Weekly plan location:
```
C:\Users\Admin\.openclaw\workspace\dinner-automation\data\weekly-plan.json
```

## Safety & Privacy

- ✅ The extension only runs on HEB.com
- ✅ No data is sent to external servers
- ✅ Your meal plan stays in your browser
- ✅ Open source - review the code yourself!

## Updates

To update the extension after code changes:
1. Go to `chrome://extensions/`
2. Find "HEB Auto-Cart"
3. Click the refresh icon (↻)
4. The extension will reload with the latest code

## Uninstallation

1. Go to `chrome://extensions/`
2. Find "HEB Auto-Cart"
3. Click "Remove"
4. Confirm removal

## Support

For issues or questions, check the troubleshooting section above or review the console logs:
1. Right-click on the popup → Inspect
2. Click the Console tab
3. Look for error messages

## License

Private use - For Alexander's dinner automation system
