/**
 * HEB Auto-Cart Content Script
 * Runs on HEB.com pages to automate cart addition
 */

console.log('🛒 HEB Auto-Cart: Content script loaded');

let isRunning = false;
let items = [];
let currentIndex = 0;
let addedCount = 0;
let failedItems = [];

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message:', message);
  
  if (message.action === 'startAutomation') {
    items = message.items;
    currentIndex = 0;
    addedCount = 0;
    failedItems = [];
    
    if (!isRunning) {
      startAutomation();
    }
    sendResponse({ status: 'started', items: items.length });
    return true;
  }
  
  if (message.action === 'stopAutomation') {
    isRunning = false;
    sendResponse({ status: 'stopped' });
    return true;
  }
  
  if (message.action === 'getStatus') {
    sendResponse({ 
      isRunning, 
      currentIndex, 
      total: items.length,
      added: addedCount,
      failed: failedItems 
    });
    return true;
  }
});

/**
 * Main automation loop
 */
async function startAutomation() {
  if (isRunning) {
    console.log('Already running');
    return;
  }
  
  isRunning = true;
  console.log(`🛒 Starting automation for ${items.length} items`);
  
  // Send initial status
  chrome.runtime.sendMessage({
    action: 'automationStarted',
    total: items.length
  });
  
  for (let i = 0; i < items.length; i++) {
    if (!isRunning) {
      console.log('Automation stopped by user');
      break;
    }
    
    currentIndex = i;
    const item = items[i];
    
    console.log(`\n📦 [${i + 1}/${items.length}] Adding: ${item.name}`);
    
    // Update progress
    chrome.runtime.sendMessage({
      action: 'progress',
      completed: i,
      total: items.length,
      currentItem: item.name,
      itemStatus: 'adding'
    });
    
    try {
      const result = await addItemToCart(item);
      
      if (result.success) {
        addedCount++;
        item.status = 'done';
        console.log(`✅ Added: ${item.name}`);
        
        chrome.runtime.sendMessage({
          action: 'progress',
          completed: i + 1,
          total: items.length,
          currentItem: item.name,
          itemStatus: 'done',
          message: `Added ${item.name}`
        });
      } else {
        throw new Error(result.error || 'Unknown error');
      }
      
      // Wait between items (avoid rate limiting)
      if (i < items.length - 1) {
        const delay = 2000 + Math.random() * 2000; // 2-4 seconds
        console.log(`⏳ Waiting ${Math.round(delay)}ms...`);
        await sleep(delay);
      }
      
    } catch (error) {
      console.error(`❌ Failed to add ${item.name}:`, error);
      failedItems.push({ item: item.name, error: error.message });
      item.status = 'error';
      
      chrome.runtime.sendMessage({
        action: 'progress',
        completed: i,
        total: items.length,
        currentItem: item.name,
        itemStatus: 'error',
        error: error.message
      });
      
      // Continue with next item even if this one failed
      await sleep(1000);
    }
  }
  
  isRunning = false;
  
  // Send completion message
  chrome.runtime.sendMessage({
    action: 'automationComplete',
    added: addedCount,
    failed: failedItems.length,
    total: items.length,
    failedItems: failedItems
  });
  
  console.log(`\n✅ Automation complete! Added ${addedCount}/${items.length} items`);
  if (failedItems.length > 0) {
    console.log('Failed items:', failedItems);
  }
}

/**
 * Add a single item to cart using search and add approach
 */
async function addItemToCart(item) {
  const searchTerm = item.hebSearch || item.searchTerm || item.name;
  
  // Step 1: Enter search term in the search box
  const searchInput = findSearchInput();
  if (!searchInput) {
    throw new Error('Search input not found on page');
  }
  
  // Clear and enter search term
  searchInput.value = '';
  searchInput.focus();
  searchInput.value = searchTerm;
  
  // Trigger input event
  searchInput.dispatchEvent(new Event('input', { bubbles: true }));
  
  // Step 2: Submit search
  const searchButton = findSearchButton();
  if (searchButton) {
    searchButton.click();
  } else {
    // Try pressing Enter
    searchInput.dispatchEvent(new KeyboardEvent('keydown', { 
      key: 'Enter', 
      code: 'Enter',
      bubbles: true 
    }));
  }
  
  // Step 3: Wait for search results
  console.log('Waiting for search results...');
  await sleep(3000); // Wait for page to load results
  
  // Step 4: Find and click Add to Cart button
  const addButton = await findAddToCartButtonWithRetry(5);
  
  if (!addButton) {
    throw new Error('No Add to Cart button found for this product');
  }
  
  // Scroll into view and click
  addButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await sleep(500);
  addButton.click();
  
  // Step 5: Wait for cart update confirmation
  await sleep(1500);
  
  // Step 6: Handle any modals
  await handleModals();
  
  return { success: true };
}

/**
 * Find the search input field
 */
function findSearchInput() {
  const selectors = [
    'input[data-automation-id="searchInputBox"]',
    'input[placeholder*="Search" i]',
    'input[type="search"]',
    'input[name="q"]',
    'input[aria-label*="Search" i]',
    '#search-input',
    '.search-input'
  ];
  
  for (const selector of selectors) {
    const input = document.querySelector(selector);
    if (input) {
      console.log('Found search input:', selector);
      return input;
    }
  }
  
  // Fallback: find any input that looks like search
  const inputs = document.querySelectorAll('input');
  for (const input of inputs) {
    const placeholder = (input.placeholder || '').toLowerCase();
    const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase();
    if (placeholder.includes('search') || ariaLabel.includes('search')) {
      return input;
    }
  }
  
  return null;
}

/**
 * Find the search button
 */
function findSearchButton() {
  const selectors = [
    'button[data-automation-id="searchButton"]',
    'button[aria-label*="Search" i]',
    'button[type="submit"]',
    '.search-button',
    'button:has(svg)',
    'button[title*="Search" i]'
  ];
  
  for (const selector of selectors) {
    const button = document.querySelector(selector);
    if (button) return button;
  }
  
  return null;
}

/**
 * Find Add to Cart button with retry logic
 */
async function findAddToCartButtonWithRetry(maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const button = findAddToCartButton();
    if (button) return button;
    
    console.log(`Add button not found, retry ${attempt + 1}/${maxRetries}...`);
    await sleep(1000);
  }
  
  return null;
}

/**
 * Find the Add to Cart button on the page
 */
function findAddToCartButton() {
  // Try multiple selectors (HEB uses different ones)
  const selectors = [
    'button[data-automation-id="addToCartButton"]',
    'button[data-testid="add-to-cart"]',
    'button:contains("Add to Cart")',
    'button span:contains("Add")',
    '.add-to-cart-button',
    '[data-automation-id*="addToCart" i]',
    'button[aria-label*="Add to Cart" i]',
    'button.btn-primary:contains("Add")'
  ];
  
  for (const selector of selectors) {
    try {
      const button = document.querySelector(selector);
      if (button && !button.disabled && button.offsetParent !== null) {
        console.log('Found add button:', selector);
        return button;
      }
    } catch (e) {
      // Some selectors might not be valid
    }
  }
  
  // Try by text content
  const buttons = document.querySelectorAll('button, a');
  for (const button of buttons) {
    const text = (button.textContent || '').toLowerCase().trim();
    if (text === 'add to cart' || text === 'add' || text.includes('add to cart')) {
      if (!button.disabled && button.offsetParent !== null) {
        return button;
      }
    }
  }
  
  return null;
}

/**
 * Handle any popup modals that appear
 */
async function handleModals() {
  const modalCloseSelectors = [
    'button[aria-label="Close"]',
    'button[data-automation-id="closeModal"]',
    'button:contains("Close")',
    'button:contains("No Thanks")',
    'button:contains("Continue Shopping")',
    '.modal-close',
    '[data-testid="modal-close"]'
  ];
  
  for (const selector of modalCloseSelectors) {
    try {
      const button = document.querySelector(selector);
      if (button && button.offsetParent !== null) {
        console.log('Closing modal with:', selector);
        button.click();
        await sleep(500);
      }
    } catch (e) {}
  }
}

/**
 * Sleep utility
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Listen for page unload
window.addEventListener('beforeunload', () => {
  if (isRunning) {
    chrome.runtime.sendMessage({
      action: 'automationError',
      error: 'Page navigated away during automation'
    });
  }
});

// Log when script loads
console.log('🛒 HEB Auto-Cart: Content script ready');
